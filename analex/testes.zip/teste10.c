int main()
{
  int a, x;
  float b;
  a = x + b;
  b = x*x + a;
  b = b - 2;
  print(a);
  print(b);
  print(x);  
}
